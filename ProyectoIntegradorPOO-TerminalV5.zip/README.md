# ProyectoIntegradorPOO
***
En el presente repositorio se encuentran los recursos empleados para la realzación de nuestro proyecto integrador hecho en Java. <br>
Los integrantes del grupo somos:
- Amoretti, Jesu
- Lujan, Cesar
- Romero, Fabrizio

/*
 * 
 * 
 */
package paquete.programas;

/**
 *
 * @author Jesu
 */
public class JuegoX extends Programa{

    public JuegoX(String nombre) {
        super(nombre);
    }

    @Override
    public void ingresarOpciones() {
        
    }

    @Override
    public void iniciarPrograma() {
        ingresarOpciones();
    }
    
}

package paquete.programas;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import paquete.interfaces.Mensajes;

public class Calculadora extends Programa implements Mensajes {

    public Calculadora(String nombre) {
        super(nombre);
    }

    public String ordenarLista(ArrayList X) {
        String cad = "";
        Iterator<Integer> puntero = X.iterator();
        int contador = 0;
        while (puntero.hasNext()) {
            cad += puntero.next() + ", ";
            contador++;
            if (contador > 12) {
                cad += "/";
                contador = 0;
            }
        }
        return cad;
    }

    public void verAcercaDe() {
        Scanner sc = new Scanner(System.in);
        limpiarDisplay(1);
        acomodarTexto(CALC1, 3, 3);
        System.out.println(mostrarDisplay());
        System.out.println(ENTER);
        sc.nextLine();
    }

    public void Calcular() {
        String[] operaciones = new String[] { "Suma", "Resta", "Multiplicación", "División", "Número primo",
                "Sumatoria", "Factorial", "" };
        Scanner sc = new Scanner(System.in);
        int Opcion = 0;

        do {
            limpiarDisplay(1);
            acomodarTexto(CALC2, 3, 3);
            acomodarTexto(CALC3, 6, 3);
            System.out.println(mostrarDisplay());
            System.out.println("Digite su opción a realizar:");
            Opcion = sc.nextInt();
            limpiarDisplay(1);

            ingresarTexto(operaciones[Opcion - 1], 5, 3);
            if (Opcion <= 4) {
                // Desde suma a división (dos números)
                float Num1, Num2, Resultado = 0;

                ingresarTexto("* Ingrese el primer número: ", 4, 4);
                System.out.println(mostrarDisplay());
                System.out.println("Digite su número");
                Num1 = sc.nextFloat();
                ingresarTexto("* Ingrese el primer número: " + String.valueOf(Num1), 4, 4);
                limpiarDisplay(0);
                ;

                ingresarTexto("* Ingrese el segundo número", 4, 5);
                System.out.println(mostrarDisplay());
                System.out.println("Digite su número");
                Num2 = sc.nextFloat();
                ingresarTexto("* Ingrese el primer número: " + String.valueOf(Num2), 4, 4);
                limpiarDisplay(0);
                ;

                switch (Opcion) {
                    case 1: {
                        Resultado = Num1 + Num2;
                        break;
                    }
                    case 2: {
                        Resultado = Num1 - Num2;
                        break;
                    }
                    case 3: {
                        Resultado = Num1 * Num2;
                        break;
                    }
                    case 4: {
                        if (Num2 == 0) {
                            System.out.println("Como vas a dividir entre 0 wtf");
                        }
                        Resultado = Num1 / Num2;
                        break;
                    }
                    default: {
                        System.out.println(PROGFAIL);
                    }
                }
                ingresarTexto("** El resultado es: " + Resultado, 3, 6);

            } else if (4 < Opcion && Opcion < 8) {
                /* Desde número primo a factorial (trabajo de naturales en array's) */
                int Num1;
                // Clase genérica
                ArrayList<Integer> listaAux = new ArrayList<Integer>();

                ingresarTexto("* Ingrese su número a trabajar", 4, 4);
                System.out.println(mostrarDisplay());
                System.out.println("Digite su número");
                Num1 = sc.nextInt();
                ingresarTexto(String.valueOf(Num1), 9, 4);
                limpiarDisplay(0);
                ;

                switch (Opcion) {
                    case 5: {
                        // Número primo
                        if (Num1 <= 1) {
                            ingresarTexto("El número ingresado no puede ser analizado", 3, 5);
                            break;
                        }
                        int cantDivisores = 1;
                        String esPrimo = "es primo";
                        boolean unaVez = true;
                        for (int i = 1; i < Num1; i++) {
                            if (Num1 % i == 0) {
                                listaAux.add(i);
                                cantDivisores++;
                            }
                            if (cantDivisores > 2 && unaVez == true) {
                                esPrimo = "no es primo";
                                unaVez = false;
                            }
                        }
                        ingresarTexto("** El número ingresado " + esPrimo, 3, 5);

                        String cad = ordenarLista(listaAux);
                        acomodarTexto("Los divisores son: " + cad + "y " + Num1 + "/", 3, 6);
                        break;
                    }
                    case 6: {
                        // Sumatoria
                        if (Num1 <= 1) {
                            ingresarTexto("El número ingresado no puede ser analizado", 3, 5);
                            break;
                        }
                        int numIni = 0, saltoNum = 1, sumaTotal = 0;
                        ingresarTexto("* Ingrese el número de inicio de la sumatoria", 4, 5);
                        System.out.println(mostrarDisplay());
                        System.out.println("Digite su número");
                        numIni = sc.nextInt();
                        limpiarDisplay(0);
                        ;
                        ingresarTexto(String.valueOf(numIni), 9, 5);
                        ingresarTexto("* Ingrese el salto entre números: ", 4, 6);
                        System.out.println(mostrarDisplay());
                        System.out.println("Digite su número");
                        saltoNum = sc.nextInt();
                        ingresarTexto(String.valueOf(saltoNum), 9, 6);
                        while (saltoNum == 0) {
                            System.out.println("Ingrese un número válido:");
                            saltoNum = sc.nextInt();
                        }
                        for (int i = numIni; i <= Num1; i += saltoNum) {
                            listaAux.add(i);
                            sumaTotal += i;
                        }
                        String cad = ordenarLista(listaAux);
                        ingresarTexto("* La sumatoria resulta ", 3, 7);
                        ingresarTexto(String.valueOf(sumaTotal), 4, 7);
                        acomodarTexto("* La suma fue de los números:/" + cad + "/", 3, 8);
                        break;
                    }
                    case 7: {
                        // Factorial
                        int Resultado = Num1;
                        System.out.println(Resultado);
                    }
                    default: {
                        System.out.println(PROGFAIL);
                    }
                }
            } else {
                System.out.println("Cerrando la calculadora.");
                break;
            }
            System.out.println(mostrarDisplay());
            System.out.println(ENTER);
            sc.nextLine();
            sc.nextLine(); // Dos veces por el nextfloat
        } while (Opcion != 8);
    }

    @Override
    public void ingresarOpciones() {
        Scanner sc = new Scanner(System.in);
        int X;

        do {
            limpiarDisplay(1);
            acomodarTexto(CALCOP, 3, 3);
            System.out.println(mostrarDisplay());
            System.out.println("Ingrese el número de opción.");
            X = sc.nextInt();
            switch (X) {
                case 1: {
                    verAcercaDe();
                    break;
                }
                case 2: {
                    Calcular();
                    break;
                }
                case 3: {
                    break;
                }
                default: {
                    ingresarTexto(PROGFAIL, 3, 3);
                    esperar(2);
                    sc.close();
                }
            }
        } while (X != 3);
    }

    @Override
    public void limpiarDisplay(int X) {
        super.limpiarDisplay(X);
        ingresarTexto("Calculadora", 5, 1);
    }

    @Override
    public void iniciarPrograma() {
        ingresarOpciones();
    }

}
